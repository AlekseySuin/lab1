package com.example.lab_1

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.core.view.isVisible

class MainActivity : AppCompatActivity() {
    @Override
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val button = findViewById<Button>(R.id.button_1);
        val textView = findViewById<TextView>(R.id.textView2);
        val text_input = findViewById<TextView>(R.id.plain_text_input)
        button.setOnClickListener(){
            textView.text = text_input.text.toString()
            textView.isVisible = true
        }
    }
    /*fun onTestButtonClick(view: View){
        val myToast = Toast.makeText(this, "Привет, мир!", Toast.LENGTH_SHORT).show()
    }*/
}